from django.shortcuts import render, redirect  
from django.contrib.auth import authenticate, login, logout #import Log In And Log Out
from django.contrib.auth.models import User                 #import User 
from employee.forms import EmployeeForm  
from employee.models import Employee  
from django.http import HttpResponse
from django.contrib import messages
# Create your views here. 

#Show the Franted
def Index(request):   
    return render(request,'index.html')

#Add data into the table...................
def Add(request):  
    if request.method == "POST":  
        form = EmployeeForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                messages.success(request, "Add Successfully")
                return redirect('/show')  
            except:  
                pass  
    else:  
        form = EmployeeForm()  
    return render(request,'add.html',{'form':form})  

# Show the all data into the table.........................
def show(request):  
    employees = Employee.objects.all()  
    return render(request,"show.html",{'employees':employees}) 

#Edit the data into the data table............
def edit(request, id):  
    employee = Employee.objects.get(id=id)  #Get data thruogh id
    return render(request,'edit.html', {'employee':employee})  

#Update The data into the table.....................
def update(request, id):  
    employee = Employee.objects.get(id=id)  
    form = EmployeeForm(request.POST, instance = employee)  
    if form.is_valid():  
        form.save()
        messages.success(request, "Update Successfully")
        return redirect("/show")  
    return render(request, 'edit.html', {'employee': employee})

#Destroy the data into the table......................
def destroy(request, id):  
    employee = Employee.objects.get(id=id)  
    employee.delete()  
    messages.error(request, "Delete Successfully")
    return redirect("/show")  

def HandleSignUp(request):
    if request.method == 'POST':
        # Get The Parameters....................
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        #Check For errorneous Input
        # Username should be under 10 Charecters
        if len(username) > 10:
            return redirect('Index')
        #End Check For errorneous Input
        #Username Should Be Alphanumeric
        if username.isalnum(): #isalnum() Function is Check Username letters and Number
            messages.error(request, "Username Should Only Contain letters and Numers")
            return redirect('Index')
        # Check Paas1 Equale Pass2
        #Password Should Be Match
        if pass1 !=pass2:
            return redirect('Index')
        #Create The User
        myuser = User.objects.create_user(username, email, pass1)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.save()
        return redirect('Index')
    else:
        return HttpResponse('404- Not Found')

def HandleLogin(request):
    if request.method =='POST':
        loginusername = request.POST['loginusername']
        loginpass = request.POST['loginpass']
        user = authenticate(username=loginusername, password=loginpass)
        #Check User Is Not None
        if user is not None:
            login(request,user)
            messages.success(request, "Successfully Logged In")
            return redirect('Index')
        else:
            messages.error(request, "Invalid Credentials Please Try Again")
            return redirect('Index')
    return HttpResponse('404- Not Found')

def HandleLogOut(request):
    logout(request)
    messages.success(request, "Successfully Logged Out")
    return redirect('Index')